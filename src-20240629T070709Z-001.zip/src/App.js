import React from 'react';
import ProfilePage from './ProfilePage';

function App() {
  return (
    <div className="App">
      <ProfilePage />
    </div>
  );
}

export default App;
