import React from 'react';
import ProfilePicture from './ProfilePicture';
import ProfileDetails from './ProfileDetails';
import './ProfilePage.css';

const ProfilePage = () => {
  const user = {
    profilePicture: 'https://res.cloudinary.com/dtdhmbtcg/image/upload/v1717091701/IMG_20210802_094632_ajd4cw.jpg',
    name: 'Sailesh Vutukuri',
    email: 'saileshvutukuri@gmail.com',
    bio: 'As a driven engineering student with a deep enthusiasm for the industry, I am actively seeking diverse opportunities to apply and enhance my skills. I am eager to contribute to innovative projects and collaborate within a dynamic team, aligning with my career objectives'
  };

  return (
    <div className="profile-page">
      <ProfilePicture url={user.profilePicture} />
      <ProfileDetails name={user.name} email={user.email} bio={user.bio} />
    </div>
  );
};

export default ProfilePage;
